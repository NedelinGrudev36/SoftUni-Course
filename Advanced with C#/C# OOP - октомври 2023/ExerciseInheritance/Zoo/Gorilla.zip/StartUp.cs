﻿namespace Zoo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}